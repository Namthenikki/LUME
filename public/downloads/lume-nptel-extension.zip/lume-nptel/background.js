import { LMS, readLms } from './lms.js';
import { enrolledCourseFromUrl, ORIGIN, readAll } from './nptel.js';

// Syncs NPTEL deadlines, and the posts in your MUJ LMS courses (for quizzes announced there), to
// Lume every hour while Chrome is open, when Chrome starts, and whenever you're on NPTEL or the LMS.
// After a failure (say you were logged out) it tries again every 10 minutes, and as soon as you
// open either site again.
const EVERY_MINUTES = 60;
const RETRY_MINUTES = 10;
const VISIT_RESYNC_MS = 30 * 60_000;
const VISIT_RETRY_MS = 15_000;
// Just after you submit a quiz (the LMS shows its submissions page), so Lume ticks it before it nags you.
const SUBMITTED_RESYNC_MS = 20_000;
const SUBMITTED_PAGE = /\/d2l\/lms\/quizzing\/user\/(quiz_submissions|quizzes_list)/;
export const DEFAULT_LUME_URL = 'https://lume-three-iota.vercel.app';

const store = chrome.storage.local;
const getConfig = async () => ({ lumeUrl: DEFAULT_LUME_URL, key: '', courses: [], ...(await store.get(['lumeUrl', 'key', 'courses'])) });

/** The regular sync timer; replaced when its interval changed in an update, since Chrome keeps the old one. */
async function ensureAlarm() {
  const alarm = await chrome.alarms.get('sync');
  if (alarm?.periodInMinutes !== EVERY_MINUTES) await chrome.alarms.create('sync', { periodInMinutes: EVERY_MINUTES, delayInMinutes: 1 });
}

chrome.runtime.onInstalled.addListener(() => ensureAlarm().then(() => sync('install')));
chrome.runtime.onStartup.addListener(() => ensureAlarm().then(() => sync('startup')));
chrome.alarms.onAlarm.addListener((a) => (a.name === 'sync' || a.name === 'retry') && sync(a.name));
ensureAlarm(); // Chrome may drop alarms on a restart; this puts it back whenever the extension wakes

// Being on a site syncs it when the last result is over half an hour old, or failed (you were logged
// out and have just logged in) more than a few seconds ago.
const dueOnVisit = (s) => !s || Date.now() - s.at > (s.ok ? VISIT_RESYNC_MS : VISIT_RETRY_MS);

// Any page on NPTEL or the LMS: one that loads, a move inside their single-page apps, switching to
// its tab, or coming back to Chrome with it open. Opening an NPTEL course you haven't synced before adds it.
chrome.tabs.onUpdated.addListener((_tabId, change, tab) => {
  if (change.status === 'complete' || change.url) onSitePage(tab.url ?? '');
});
chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.get(tabId).then((tab) => onSitePage(tab.url ?? ''), () => {});
});
chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) return;
  chrome.tabs.query({ active: true, windowId }).then(([tab]) => tab && onSitePage(tab.url ?? ''), () => {});
});

async function onSitePage(url) {
  if (url.startsWith(`${LMS}/d2l/`) && !url.includes('/d2l/login')) {
    const { lmsState } = await store.get('lmsState');
    if (SUBMITTED_PAGE.test(url) ? !lmsState || Date.now() - lmsState.at > SUBMITTED_RESYNC_MS : dueOnVisit(lmsState)) syncLms('visit');
    return;
  }
  if (!url.startsWith(`${ORIGIN}/`)) return;
  const id = enrolledCourseFromUrl(url);
  const { courses } = await getConfig();
  if (id && !courses.some((c) => c.id === id)) {
    await store.set({ courses: [...courses, { id, name: id }] });
    return syncNptel('new course');
  }
  const { state } = await store.get('state');
  if (dueOnVisit(state)) syncNptel('visit');
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === 'sync') sync('manual').then(reply);
  return msg?.type === 'sync'; // keeps the channel open for the async reply
});

/** Fetches from inside an open NPTEL tab, for when Chrome won't attach cookies to the extension's own requests. */
const inTab = (tabId) => async (url) => {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    args: [url],
    func: async (u) => {
      const res = await fetch(u, { credentials: 'include', cache: 'no-store' });
      return { status: res.status, text: await res.text(), redirected: res.redirected, url: res.url };
    },
  });
  if (result.redirected && !result.url.startsWith(ORIGIN)) return { status: 401, json: null };
  let json = null;
  try {
    json = JSON.parse(result.text);
  } catch {}
  return { status: result.status, json };
};

/** Fetches from inside an open LMS tab, for when Chrome won't attach cookies to the extension's own requests. */
const lmsInTab = (tabId) => async (url, init = {}) => {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    args: [url, init],
    func: async (u, i) => {
      const res = await fetch(u, { ...i, credentials: u.startsWith(location.origin) ? 'include' : 'omit', cache: 'no-store' });
      return { status: res.status, url: res.url, text: await res.text() };
    },
  });
  return result;
};

let running = null;
let runningLms = null;

/** One sync of each kind at a time; a second request while one runs gets the same result. */
function syncNptel(reason) {
  running ??= run(reason).finally(() => (running = null));
  return running;
}

function syncLms(reason) {
  runningLms ??= runLms(reason).finally(() => (runningLms = null));
  return runningLms;
}

/** Both; answers with the NPTEL result, which the popup shows first. */
function sync(reason) {
  return Promise.all([syncNptel(reason), syncLms(reason)]).then(([nptel]) => nptel);
}

async function run(reason) {
  const config = await getConfig();
  const { cache = {} } = await store.get('cache');
  const at = Date.now();
  const names = Object.fromEntries(config.courses.map((c) => [c.id, c.name]));

  if (!config.key) return finish({ at, ok: false, setup: true, message: 'Paste your connection code from Lume → Settings → NPTEL' });
  if (config.courses.length === 0) return finish({ at, ok: false, setup: true, message: 'Open each of your NPTEL courses once in Chrome, or add them below' });

  const ids = config.courses.map((c) => c.id);
  let read = await readAll(ids, { cache, names });
  // Signed out as far as the extension can tell, but an NPTEL tab is open: try from inside it.
  if (read.error) {
    const [tab] = await chrome.tabs.query({ url: `${ORIGIN}/*` });
    if (tab?.id) read = await readAll(ids, { cache, names, get: inTab(tab.id) }).catch(() => read);
  }
  await store.set({ cache });
  if (!read.error) await store.set({ courses: config.courses.map((c) => ({ ...c, name: read.courses.find((r) => r.id === c.id && r.ok)?.name ?? c.name })) });

  // Tell Lume, which reminds you on your phone. Errors go too, so your phone hears about them.
  let posted;
  try {
    const res = await fetch(`${config.lumeUrl.replace(/\/+$/, '')}/api/ingest/nptel`, {
      method: 'POST',
      headers: { authorization: `Bearer ${config.key}`, 'content-type': 'application/json' },
      body: JSON.stringify({ version: chrome.runtime.getManifest().version, ...read }),
      signal: AbortSignal.timeout(30_000),
    });
    const body = await res.json().catch(() => ({}));
    posted = res.ok ? { ...body, ok: true } : { ok: false, error: body.error ?? `Lume answered ${res.status}` };
  } catch {
    posted = { ok: false, error: 'Couldn’t reach Lume. Check your internet connection' };
  }

  const failed = read.courses.filter((c) => !c.ok);
  const ok = !read.error && failed.length === 0 && posted.ok;
  const message = read.error ?? (failed.length ? `Couldn’t read ${failed.map((c) => c.name).join(', ')}: ${failed[0].error}` : posted.ok ? '' : posted.error);
  return finish({ at, ok, reason, message, signedOut: !!read.error, courses: read.courses, items: read.items, posted });
}

async function finish(state) {
  await store.set({ state });
  await showBadge();
  if (!state.ok && !state.setup) await chrome.alarms.create('retry', { delayInMinutes: RETRY_MINUTES });
  return state;
}

/** Reads your LMS course posts and quizzes and sends them to Lume, which picks out the quizzes announced in the posts. */
async function runLms(reason) {
  const config = await getConfig();
  const at = Date.now();
  if (!config.key) return finishLms({ at, ok: false, setup: true, message: 'Paste your connection code from Lume → Settings → NPTEL' });

  let read = await readLms();
  // Signed out as far as the extension can tell, but an LMS tab is open: try from inside it.
  if (read.signedOut) {
    const [tab] = await chrome.tabs.query({ url: `${LMS}/d2l/*` });
    if (tab?.id) read = await readLms({ get: lmsInTab(tab.id) }).catch(() => read);
  }

  // Errors go to Lume too, so the app can say when posts haven't been read for a while.
  let posted;
  try {
    const res = await fetch(`${config.lumeUrl.replace(/\/+$/, '')}/api/ingest/lms`, {
      method: 'POST',
      headers: { authorization: `Bearer ${config.key}`, 'content-type': 'application/json' },
      body: JSON.stringify({ version: chrome.runtime.getManifest().version, error: read.error, courses: read.courses, posts: read.posts, quizzes: read.quizzes }),
      signal: AbortSignal.timeout(30_000),
    });
    const body = await res.json().catch(() => ({}));
    posted = res.ok ? { ...body, ok: true } : { ok: false, error: body.error ?? `Lume answered ${res.status}` };
  } catch {
    posted = { ok: false, error: 'Couldn’t reach Lume. Check your internet connection' };
  }

  const failed = read.courses.filter((c) => !c.ok);
  const ok = !read.error && failed.length === 0 && posted.ok;
  const message = read.error ?? (failed.length ? `Couldn’t read ${failed.map((c) => c.name).join(', ')}: ${failed[0].error}` : posted.ok ? '' : posted.error);
  const { lmsState: previous } = await store.get('lmsState');
  return finishLms({
    at,
    ok,
    reason,
    message,
    signedOut: !!read.signedOut,
    courses: read.courses.length,
    posts: read.posts.length,
    // Kept from the last good run while signed out, so the popup still lists them.
    quizzes: posted.ok && !read.error ? (posted.quizzes ?? []) : (previous?.quizzes ?? []),
  });
}

async function finishLms(lmsState) {
  await store.set({ lmsState });
  await showBadge();
  if (!lmsState.ok && !lmsState.setup) await chrome.alarms.create('retry', { delayInMinutes: RETRY_MINUTES });
  return lmsState;
}

/** "!" on the toolbar icon while NPTEL or the LMS needs a look: red for a problem, blue for setup. */
async function showBadge() {
  const { state, lmsState } = await store.get(['state', 'lmsState']);
  const all = [state, lmsState].filter(Boolean);
  const problem = all.find((s) => !s.ok && !s.setup);
  const shown = problem ?? all.find((s) => !s.ok);
  chrome.action.setBadgeText({ text: shown ? '!' : '' });
  chrome.action.setBadgeBackgroundColor({ color: problem ? '#f04438' : '#1d6ef5' });
  chrome.action.setTitle({ title: shown ? `Lume: ${shown.message}` : 'Lume: synced' });
}
